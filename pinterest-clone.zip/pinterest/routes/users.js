const mongoose = require('mongoose');
const plm = require("passport-local-mongoose");

const Schema = mongoose.Schema;
mongoose.connect("mongodb://127.0.0.1:27017/pinterest");

const userSchema = new Schema({
    username: {
        type: String,
        required: true,
        
        
    },
    password: {
        type: String
    },
    posts:[{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Post'
    }],
    dp: {
        type: String,
        default: 'default_dp.jpg' // Assuming a default image path
    },
    email: {
        type: String,
        required: true, 
    },
    fullname: {
        type: String,
        required: true
    }
});

userSchema.plugin(plm);
module.exports  = mongoose.model('User', userSchema);

